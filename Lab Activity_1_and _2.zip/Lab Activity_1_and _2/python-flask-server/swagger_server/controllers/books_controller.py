import connexion
import six

from swagger_server.models.books import Books  # noqa: E501
from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server import util

arr = []
def add_book(books=None):  # noqa: E501
    """Add a new book to the library

    add new book with book name and bookid to the library # noqa: E501

    :param books: book object that needs to be added to the library
    :type books: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        books = Books.from_dict(connexion.request.get_json())  # noqa: E501
        arr.append(books)
    return books


def get_book():  # noqa: E501
    """Add a new book to the library

    get book details with book name and bookid # noqa: E501


    :rtype: List[InlineResponse200]
    """
    return arr
